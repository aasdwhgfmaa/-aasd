from flask import Flask, request, jsonify
from datetime import datetime, timezone
import database

app = Flask(__name__)
database.init_db()

@app.post("/verify")
def verify():
    data = request.get_json(silent=True) or {}
    key = data.get("license")
    server_uuid = data.get("server_uuid")

    if not key or not server_uuid:
        return jsonify(success=False, message="Missing license or server_uuid"), 400

    row = database.get_license(key)

    if row is None:
        return jsonify(success=False, message="License not found"), 404

    if row["active"] != 1:
        return jsonify(success=False, message="License revoked"), 403

    try:
        expires = datetime.fromisoformat(row["expires_at"])
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
    except ValueError:
        return jsonify(success=False, message="Invalid expiration"), 500

    now = datetime.now(timezone.utc)

    if now >= expires:
        return jsonify(success=False, message="License expired"), 403

    registered = row["server_uuid"]

    if registered is None:
        database.bind_server(key, server_uuid)
    elif registered != server_uuid:
        return jsonify(
            success=False,
            message="License already bound to another server"
        ), 403

    return jsonify(
        success=True,
        expires_at=expires.isoformat(),
        server_uuid=server_uuid
    )

@app.get("/health")
def health():
    return jsonify(ok=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
