import sqlite3

DB = "licenses.db"

def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS licenses (
            license_key TEXT PRIMARY KEY,
            expires_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            server_uuid TEXT,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """)

def create_license(key, expires_at, created_by, created_at):
    with connect() as conn:
        conn.execute(
            """INSERT INTO licenses
               (license_key, expires_at, created_by, created_at)
               VALUES (?, ?, ?, ?)""",
            (key, expires_at, created_by, created_at)
        )

def get_license(key):
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM licenses WHERE license_key = ?", (key,)
        ).fetchone()

def list_licenses():
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM licenses ORDER BY created_at DESC"
        ).fetchall()

def revoke_license(key):
    with connect() as conn:
        cur = conn.execute(
            "UPDATE licenses SET active = 0 WHERE license_key = ?", (key,)
        )
        return cur.rowcount > 0

def activate_license(key):
    with connect() as conn:
        cur = conn.execute(
            "UPDATE licenses SET active = 1 WHERE license_key = ?", (key,)
        )
        return cur.rowcount > 0

def bind_server(key, server_uuid):
    with connect() as conn:
        conn.execute(
            "UPDATE licenses SET server_uuid = ? WHERE license_key = ?",
            (server_uuid, key)
        )
