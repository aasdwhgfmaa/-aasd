import os
import secrets
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands

import database

TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN 환경변수가 없습니다.")

# 라이선스 명령어를 허용할 Discord 채널 ID
LICENSE_CHANNEL_ID = int(os.getenv("LICENSE_CHANNEL_ID", "0"))

database.init_db()

intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

def generate_license():
    return "UBW-" + "-".join(secrets.token_hex(3).upper() for _ in range(3))

def admin_only(interaction):
    return interaction.guild is not None and interaction.user.guild_permissions.administrator


async def check_license_channel(interaction):
    if LICENSE_CHANNEL_ID == 0:
        await interaction.response.send_message(
            "❌ LICENSE_CHANNEL_ID가 설정되지 않았습니다.",
            ephemeral=True
        )
        return False

    if interaction.channel_id != LICENSE_CHANNEL_ID:
        await interaction.response.send_message(
            "❌ 라이선스 명령어는 지정된 라이선스 채널에서만 사용할 수 있습니다.",
            ephemeral=True
        )
        return False

    return True

@tree.command(name="license_create", description="라이선스를 발급합니다.")
@app_commands.describe(days="사용 기간(일)")
async def license_create(interaction: discord.Interaction, days: int):
    if not admin_only(interaction):
        await interaction.response.send_message("관리자만 사용할 수 있습니다.", ephemeral=True)
        return
    if not await check_license_channel(interaction):
        return
    if not 1 <= days <= 3650:
        await interaction.response.send_message("기간은 1~3650일입니다.", ephemeral=True)
        return

    now = datetime.now(timezone.utc)
    expires = now + timedelta(days=days)
    key = generate_license()

    database.create_license(key, expires.isoformat(), str(interaction.user.id), now.isoformat())

    await interaction.response.send_message(
        f"✅ 라이선스 발급 완료\n키: `{key}`\n기간: `{days}일`\n만료: `{expires:%Y-%m-%d %H:%M UTC}`"
    )

@tree.command(name="license_info", description="라이선스 정보를 확인합니다.")
@app_commands.describe(key="라이선스 키")
async def license_info(interaction: discord.Interaction, key: str):
    if not admin_only(interaction):
        await interaction.response.send_message("관리자만 사용할 수 있습니다.", ephemeral=True)
        return
    if not await check_license_channel(interaction):
        return

    row = database.get_license(key)
    if row is None:
        await interaction.response.send_message("❌ 라이선스를 찾을 수 없습니다.", ephemeral=True)
        return

    status = "ACTIVE" if row["active"] else "REVOKED"
    server = row["server_uuid"] or "미등록"

    await interaction.response.send_message(
        f"키: `{row['license_key']}`\n"
        f"상태: `{status}`\n"
        f"만료: `{row['expires_at']}`\n"
        f"서버 UUID: `{server}`",
        ephemeral=True
    )

@tree.command(name="license_revoke", description="라이선스를 정지합니다.")
@app_commands.describe(key="라이선스 키")
async def license_revoke(interaction: discord.Interaction, key: str):
    if not admin_only(interaction):
        await interaction.response.send_message("관리자만 사용할 수 있습니다.", ephemeral=True)
        return
    if not await check_license_channel(interaction):
        return

    if not database.revoke_license(key):
        await interaction.response.send_message("❌ 라이선스를 찾을 수 없습니다.", ephemeral=True)
        return

    await interaction.response.send_message(f"🛑 `{key}` 정지 완료")

@tree.command(name="license_activate", description="라이선스를 다시 활성화합니다.")
@app_commands.describe(key="라이선스 키")
async def license_activate(interaction: discord.Interaction, key: str):
    if not admin_only(interaction):
        await interaction.response.send_message("관리자만 사용할 수 있습니다.", ephemeral=True)
        return
    if not await check_license_channel(interaction):
        return

    if not database.activate_license(key):
        await interaction.response.send_message("❌ 라이선스를 찾을 수 없습니다.", ephemeral=True)
        return

    await interaction.response.send_message(f"✅ `{key}` 활성화 완료")

@tree.command(name="license_list", description="라이선스 목록을 확인합니다.")
async def license_list(interaction: discord.Interaction):
    if not admin_only(interaction):
        await interaction.response.send_message("관리자만 사용할 수 있습니다.", ephemeral=True)
        return
    if not await check_license_channel(interaction):
        return

    rows = database.list_licenses()
    if not rows:
        await interaction.response.send_message("라이선스가 없습니다.", ephemeral=True)
        return

    lines = []
    for row in rows[:20]:
        status = "ACTIVE" if row["active"] else "REVOKED"
        lines.append(f"`{row['license_key']}` | {status} | {row['expires_at']}")

    await interaction.response.send_message(
        "**최근 라이선스 20개**\n" + "\n".join(lines),
        ephemeral=True
    )

@client.event
async def on_ready():
    await tree.sync()
    print(f"Discord Bot 로그인: {client.user}")

client.run(TOKEN)
