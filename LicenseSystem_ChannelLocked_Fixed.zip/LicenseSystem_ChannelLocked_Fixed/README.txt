강화 라이선스 시스템
====================

원하는 동작:
1. Python 라이선스 서버가 켜져 있을 때 최초 인증.
2. 성공하면 플러그인이 로컬 license-cache.yml에 인증 정보를 저장.
3. Python 서버가 꺼져 있으면 캐시된 인증으로 계속 작동.
4. Python 서버가 다시 켜지면 플러그인이 다시 검증.
5. 그 사이 라이선스가 만료/정지되었거나 다른 서버로 바뀌었다면 다음 온라인 검증에서 플러그인이 비활성화.
6. 서버 UUID가 바뀐 경우 온라인 검증에서 차단.
7. 캐시는 라이선스 키 자체가 아니라 서버 바인딩 정보와 마지막 성공 검증 시간을 저장.

주의:
- Python 서버가 꺼져 있는 동안에는 서버가 라이선스 정지/만료를 실시간으로 알 수 없습니다.
- 서버가 다시 연결되는 즉시 온라인 검증을 수행하고 실패하면 플러그인을 비활성화합니다.
- 판매용 배포라면 API를 반드시 HTTPS 뒤에 두세요.
- 채팅에 공개된 기존 Discord Bot 토큰은 폐기하고 새 토큰을 사용하세요.

Discord:
  /license_create 30
  /license_info KEY
  /license_revoke KEY
  /license_activate KEY
  /license_list

API:
  POST /verify
  GET /health


Discord 채널 제한
=================
라이선스 명령어는 지정된 Discord 채널에서만 작동합니다.

1. Discord 사용자 설정 -> 고급 -> 개발자 모드 ON
2. 라이선스 전용 채널 우클릭 -> ID 복사
3. 봇 실행 전에 PowerShell에서:

$env:LICENSE_CHANNEL_ID="복사한_채널_ID"
py bot.py

기존 DISCORD_TOKEN도 같은 PowerShell 창에서 설정해야 합니다.
