package com.example.license;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

public final class LicensePlugin extends JavaPlugin {

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .build();

    private File cacheFile;
    private YamlConfiguration cache;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadCache();

        String key = getConfig().getString("license-key", "").trim();
        String endpoint = getConfig().getString("license-server", "").trim();

        if (key.isEmpty() || endpoint.isEmpty()) {
            getLogger().severe("라이선스 설정이 없습니다.");
            disable();
            return;
        }

        Bukkit.getScheduler().runTaskAsynchronously(
                this,
                () -> verifyOnline(key, endpoint)
        );
    }

    private void loadCache() {
        cacheFile = new File(getDataFolder(), "license-cache.yml");
        if (!getDataFolder().exists()) {
            getDataFolder().mkdirs();
        }

        cache = YamlConfiguration.loadConfiguration(cacheFile);
    }

    private void saveCache() {
        try {
            cache.save(cacheFile);
        } catch (IOException e) {
            getLogger().warning("라이선스 캐시 저장 실패: " + e.getMessage());
        }
    }

    private void verifyOnline(String key, String endpoint) {
        try {
            UUID serverUuid = Bukkit.getWorlds().get(0).getUID();

            JsonObject json = new JsonObject();
            json.addProperty("license", key);
            json.addProperty("server_uuid", serverUuid.toString());

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(endpoint))
                    .timeout(Duration.ofSeconds(12))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json.toString()))
                    .build();

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString()
            );

            JsonObject result =
                    JsonParser.parseString(response.body()).getAsJsonObject();

            boolean success =
                    result.has("success") &&
                    result.get("success").getAsBoolean();

            if (!success) {
                String message = result.has("message")
                        ? result.get("message").getAsString()
                        : "Unknown error";

                getLogger().severe("온라인 라이선스 검증 실패: " + message);
                getLogger().severe("라이선스가 취소/만료되었거나 서버가 변경되었습니다.");

                clearCache();
                disable();
                return;
            }

            String expiresAt =
                    result.has("expires_at")
                            ? result.get("expires_at").getAsString()
                            : "";

            cache.set("license-key", key);
            cache.set("server-uuid", serverUuid.toString());
            cache.set("last-online-verification", Instant.now().toString());
            cache.set("expires-at", expiresAt);
            saveCache();

            getLogger().info("라이선스 온라인 검증 성공.");
            getLogger().info("서버 UUID 바인딩 확인 완료.");

        } catch (Exception e) {
            getLogger().warning(
                    "라이선스 서버에 연결할 수 없습니다: " + e.getMessage()
            );

            if (useOfflineCache(key)) {
                getLogger().warning(
                        "Python 라이선스 서버가 꺼져 있어 마지막 성공 인증을 사용합니다."
                );
                getLogger().info("오프라인 라이선스 모드로 플러그인을 실행합니다.");
            } else {
                getLogger().severe(
                        "사용 가능한 라이선스 캐시가 없습니다. 플러그인을 종료합니다."
                );
                disable();
            }
        }
    }

    private boolean useOfflineCache(String key) {
        String cachedKey = cache.getString("license-key", "");
        String cachedServer = cache.getString("server-uuid", "");
        String lastVerification =
                cache.getString("last-online-verification", "");

        if (!key.equals(cachedKey)) {
            return false;
        }

        if (cachedServer.isEmpty()) {
            return false;
        }

        try {
            UUID currentUuid = Bukkit.getWorlds().get(0).getUID();

            if (!cachedServer.equals(currentUuid.toString())) {
                getLogger().severe(
                        "서버 UUID가 변경되었습니다."
                );
                return false;
            }

            Instant last = Instant.parse(lastVerification);

            long graceHours =
                    getConfig().getLong("offline-grace-hours", 720);

            Instant limit =
                    last.plus(Duration.ofHours(graceHours));

            if (Instant.now().isAfter(limit)) {
                getLogger().severe(
                        "오프라인 라이선스 허용 기간이 만료되었습니다."
                );
                return false;
            }

            String expiresAt =
                    cache.getString("expires-at", "");

            if (!expiresAt.isEmpty()) {
                Instant expires = Instant.parse(expiresAt);

                if (Instant.now().isAfter(expires)) {
                    getLogger().severe(
                            "라이선스 만료 시간이 지났습니다."
                    );
                    return false;
                }
            }

            return true;

        } catch (Exception e) {
            return false;
        }
    }

    private void clearCache() {
        cacheFile.delete();
    }

    private void disable() {
        Bukkit.getScheduler().runTask(
                this,
                () -> Bukkit.getPluginManager().disablePlugin(this)
        );
    }
}
